export interface IUser {
  
    email:string,
    permission:string,
    profile:string,
}
