export class User{
	constructor(
			public department:string,
			public role:string,
			public email:string,
			public mobile:string
		){}
	
}