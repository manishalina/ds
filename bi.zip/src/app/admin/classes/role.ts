export class Role{
	constructor(
			public name:string,
			public permission_map:any[],
		){}
	
}