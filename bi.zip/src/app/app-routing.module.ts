import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './admin/screen/user/user.component';
import { RoleComponent } from './admin/screen/role/role.component';
import { DepartmentComponent } from './admin/screen/department/department.component';
import { AuthGuard } from './auth.guard';
import { DashboardComponent } from './admin/screen/dashboard/dashboard.component';
//import { PermissionComponent } from './admin/screen/permission/permission.component';


const routes: Routes = [

  {
    path:'',
    redirectTo:'dashboard',
    pathMatch:'full'
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'user',
    component:UserComponent,
    canActivate:[AuthGuard]

  },

  {
    path:'role',
    component:RoleComponent,
    canActivate:[AuthGuard]
  },
  {
    path:'department',
    component:DepartmentComponent,
    canActivate:[AuthGuard]
  },
  {
    path:'dashboard',
    component:DashboardComponent,
    canActivate:[AuthGuard]
  },
  // // {
  // //   path:'permission',
  // //   component:PermissionComponent
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
